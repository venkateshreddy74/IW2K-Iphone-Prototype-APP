//
//  FYFLBeHealthyViewController.m
//  IW2K
//
//  Created by Connie McLaurin on 7/23/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import "FYFLBeHealthyViewController.h"
#import "FYFLWebContentViewController.h"

@interface FYFLBeHealthyViewController ()

@end

@implementation FYFLBeHealthyViewController
@synthesize navigationBar;

@synthesize beHealthyPic;
@synthesize beHealthyText;

@synthesize eating;
@synthesize waterhealth;
@synthesize safety;
@synthesize movemore;
@synthesize nutrition;
@synthesize determieater;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)changedView:(UIInterfaceOrientation) orientation {
    UIInterfaceOrientation theOrientation = self.interfaceOrientation;
    if ( theOrientation==UIInterfaceOrientationLandscapeLeft || theOrientation == UIInterfaceOrientationLandscapeRight) {
        
        /*Orientation Landscape */
        /*Root view Controller */
        navigationBar.frame=CGRectMake(0, 10, 479, 44);
        
        beHealthyPic.frame= CGRectMake(37,59,407,102);
        beHealthyText.frame= CGRectMake(29,159,432,37);
        
        
        eating.frame= CGRectMake(48,194,110,35);
        waterhealth.frame= CGRectMake(336,235,110,35);
        safety.frame= CGRectMake(190,194,110,35);
        movemore.frame= CGRectMake(48,235,110,35);
        nutrition.frame= CGRectMake(336,194,110,35);
        determieater.frame= CGRectMake(190,235,110,35);
        
        
       
        
        
    }
    else {
        navigationBar.frame=CGRectMake(0, 26, 320, 44);
        
        beHealthyPic.frame= CGRectMake(20,76,280,115);
        beHealthyText.frame= CGRectMake(23,199,272,37);
        
        
        eating.frame= CGRectMake(23,249,90,35);
        waterhealth.frame= CGRectMake(201,249,90,35);
        safety.frame= CGRectMake(112,293,90,35);
        movemore.frame= CGRectMake(23,330,90,35);
        nutrition.frame= CGRectMake(201,330,90,35);
        determieater.frame= CGRectMake(112,375,90,35);
       
        
    }
    
}
-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    [self changedView:toInterfaceOrientation];
}




- (void)viewDidLoad
{
 
    [super viewDidLoad];
    UIApplication *app= [UIApplication sharedApplication];
    UIInterfaceOrientation currentOrientation= app.statusBarOrientation;
    [self changedView:currentOrientation];
    // Do any additional setup after loading the view.
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.destinationViewController isKindOfClass:[FYFLWebContentViewController class]])
    {
        FYFLWebContentViewController* controller = (FYFLWebContentViewController *) segue.destinationViewController;
        controller.viewTitle = segue.identifier;
        
        if ([segue.identifier isEqualToString:@"Healthy Eating"])
        {
            controller.urlToLoad = @"http://www.extension.org/pages/65011/myplate-for-preschoolers#.U9KzUVZJ86F";
        }
        else if ([segue.identifier isEqualToString:@"DeterminEater"])
        {
            controller.urlToLoad = @"http://jaygreen8.wix.com/determineater";
        }
        else if ([segue.identifier isEqualToString:@"Safety&Health"])
        {
            controller.urlToLoad = @"http://www.extension.org/drinking_water";
        }
        else if ([segue.identifier isEqualToString:@"Just Move More"])
        {
            controller.urlToLoad = @"http://www.extension.org/pages/23941/tame-the-tube#.U9K0JFZJ86F";
        }
        else if ([segue.identifier isEqualToString:@"Health Nutrition"])
        {
            controller.urlToLoad = @"http://www.extension.org/healthy_food_choices_in_schools";
        }
        else if ([segue.identifier isEqualToString:@"Water&Health"])
        {
            controller.urlToLoad = @"http://www.extension.org/category/drinking_water_quantity";
        }
        else if ([segue.identifier isEqualToString:@"healthyEating"])
        {
            controller.urlToLoad = @"http://www.extension.org/pages/70399/encourage-kids-to-eat-healthy-foods:-content-group-profile#.U9Kz4VZJ86F";
        }
    }
}

@end
