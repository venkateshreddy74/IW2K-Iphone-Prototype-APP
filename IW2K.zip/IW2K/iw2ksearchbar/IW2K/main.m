//
//  main.m
//  IW2K
//
//  Created by Neda on 7/14/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "FYFLAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([FYFLAppDelegate class]));
    }
    
}
