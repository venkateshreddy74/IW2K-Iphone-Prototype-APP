//
//  FYFLViewController.h
//  IW2K
//
//  Created by Neda on 7/14/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FYFLViewController : UIViewController

/* Main Page Controllers */
@property (weak, nonatomic) IBOutlet UIButton *getScienceButton;
@property (weak, nonatomic) IBOutlet UIButton *beHealthyButton;
@property (weak, nonatomic) IBOutlet UIButton *liveResponsibilityButton;
@property (weak, nonatomic) IBOutlet UIButton *goServeButton;
@property (weak, nonatomic) IBOutlet UIImageView *iw2kBanner;

@property (strong, nonatomic) IBOutlet UITextField *searchField;

/* WebView */
@property (strong, nonatomic) IBOutlet UIWebView *extentionWebView;
@property (strong, nonatomic) IBOutlet UIWebView *fyfiWebView;
@property (weak, nonatomic) IBOutlet UIToolbar *extensionWebViewToolbar;
@property (weak, nonatomic) IBOutlet UIToolbar *fyfiWebViewToolbar;


/*Container */
@property (weak, nonatomic) IBOutlet UIView *container;
@property (weak, nonatomic) IBOutlet UIButton *extensionLogo;
@property (weak, nonatomic) IBOutlet UIButton *fyfiLogo;



//- (IBAction)textFieldDoneEditing:(id)sender;
@end
