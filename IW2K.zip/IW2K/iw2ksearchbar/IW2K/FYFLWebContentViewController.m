//
//  FYFLWebContentViewController.m
//  IW2K
//
//  Created by Ivelin Denev on 7/22/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import "FYFLWebContentViewController.h"

@interface FYFLWebContentViewController () <UIWebViewDelegate>

@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (weak, nonatomic) IBOutlet UILabel *bottomTitle;
@property (weak, nonatomic) IBOutlet UIToolbar *upperTitle;

@end

@implementation FYFLWebContentViewController



-(void)changedView:(UIInterfaceOrientation) orientation {
    UIInterfaceOrientation theOrientation = self.interfaceOrientation;
    if ( theOrientation==UIInterfaceOrientationLandscapeLeft || theOrientation == UIInterfaceOrientationLandscapeRight) {
        
        self.upperTitle.frame=CGRectMake(0, 19, 480, 44);
        
        self.webView.frame= CGRectMake(0,63,480,223);
        self.bottomTitle.frame= CGRectMake(103,282,252,38);
        
        }
    
    else {
        self.upperTitle.frame=CGRectMake(0, 18, 320, 44);
        self.webView.frame= CGRectMake(0,62,320,375);
        self.bottomTitle.frame= CGRectMake(83,437,252,38);
        
        
        }
    
}
-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    [self changedView:toInterfaceOrientation];
}





- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSURLRequest *requestURL2 = [NSURLRequest requestWithURL: [NSURL URLWithString:self.urlToLoad]];
    [self.webView loadRequest:requestURL2];
    
    
    
    self.bottomTitle.text = self.viewTitle;
    [self.bottomTitle setFont:[UIFont fontWithName:@"Arial" size:9]];
}


- (void)webViewDidStartLoad:(UIWebView *)webView{
    
    self.webView.scrollView.contentOffset = CGPointMake(0, 110);
    
}


@end
