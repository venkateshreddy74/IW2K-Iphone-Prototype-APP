//
//  FYFLGoServeViewController.h
//  IW2K
//
//  Created by Connie McLaurin on 7/23/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FYFLGoServeViewController : UIViewController
@property (weak, nonatomic) IBOutlet UINavigationBar *navigationBar;

@property (weak, nonatomic) IBOutlet UIImageView *goServePic;
@property (weak, nonatomic) IBOutlet UILabel *goServeText;

@property (weak, nonatomic) IBOutlet UIButton *foundationForVolunteers;
@property (weak, nonatomic) IBOutlet UIButton *developingVolunteers;
@property (weak, nonatomic) IBOutlet UIButton *volunteerManagers;
@property (weak, nonatomic) IBOutlet UIButton *helpChildrenServe;
@property (weak, nonatomic) IBOutlet UIButton *volunteerOrientation;


@end
