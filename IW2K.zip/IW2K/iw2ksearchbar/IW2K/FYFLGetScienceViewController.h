//
//  FYFLGetScienceViewController.h
//  IW2K
//
//  Created by Ivelin Denev on 7/22/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FYFLGetScienceViewController : UIViewController

@property (weak, nonatomic) IBOutlet UINavigationBar *navigationBar;


@property (weak, nonatomic) IBOutlet UIImageView *getSciencePic;
@property (weak, nonatomic) IBOutlet UILabel *getScienceText;

@property (weak, nonatomic) IBOutlet UIButton *water;
@property (weak, nonatomic) IBOutlet UIButton *aerospace;
@property (weak, nonatomic) IBOutlet UIButton *geospatial;
@property (weak, nonatomic) IBOutlet UIButton *agriculture;
@property (weak, nonatomic) IBOutlet UIButton *math;
@property (weak, nonatomic) IBOutlet UIButton *nature;
@property (weak, nonatomic) IBOutlet UIButton *fourHScience;
@property (weak, nonatomic) IBOutlet UIButton *energy;

@end
