//
//  FYFLViewController.m
//  IW2K
//
//  Created by Neda on 7/14/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import "FYFLViewController.h"
#import "searchViewController.h"


@interface FYFLViewController ()

@end

@implementation FYFLViewController
@synthesize extentionWebView;
@synthesize fyfiWebView;

@synthesize getScienceButton;
@synthesize beHealthyButton;
@synthesize liveResponsibilityButton;
@synthesize goServeButton;

@synthesize iw2kBanner;
@synthesize container;
@synthesize extensionLogo;
@synthesize fyfiLogo;

@synthesize extensionWebViewToolbar;
@synthesize fyfiWebViewToolbar;
- (void)viewDidLoad
{
    NSURL *url =[NSURL URLWithString:@"http://www.extension.org/"];
    NSURLRequest *requestURL = [NSURLRequest requestWithURL:url];
    [extentionWebView loadRequest:requestURL];
    NSURL *url2 = [NSURL URLWithString:@"http://www.fyflnetwork.org"];
    NSURLRequest *requestURL2 = [NSURLRequest requestWithURL:url2];
    [fyfiWebView loadRequest:requestURL2];
    
       [super viewDidLoad];
    UIApplication *app= [UIApplication sharedApplication];
    UIInterfaceOrientation currentOrientation= app.statusBarOrientation;
    [self changedView:currentOrientation];
}

-(void)changedView:(UIInterfaceOrientation) orientation {
    UIInterfaceOrientation theOrientation = self.interfaceOrientation;
    if ( theOrientation==UIInterfaceOrientationLandscapeLeft || theOrientation == UIInterfaceOrientationLandscapeRight) {
        
        /*Orientation Landscape */
        /*Root view Controller */
        iw2kBanner.frame= CGRectMake(118,39,240,40);
        _searchField.frame= CGRectMake(43,83,386,44);
        liveResponsibilityButton.frame= CGRectMake(61,139,90,85);
        getScienceButton.frame= CGRectMake(250,141,90,85);
        beHealthyButton.frame= CGRectMake(153,180,90,85);
        goServeButton.frame= CGRectMake(347,165,90,85);
        
        
        /* Container */
        container.frame=CGRectMake(0, 0, 480, 480);
        extensionLogo.frame=CGRectMake(0, 277, 110, 43);
        fyfiLogo.frame=CGRectMake(363, 279, 113, 41);
        
        
        /*FYFL Logo Webview */
        fyfiWebView.frame=CGRectMake(0, 20, 479, 254);
        fyfiWebViewToolbar.frame=CGRectMake(0, 276, 478, 44);
        
        /*Extension Logo Webview */
        extentionWebView.frame=CGRectMake(0, 20, 479, 254);
        extensionWebViewToolbar.frame=CGRectMake(0, 276, 478, 44);
        
    }
    else {
        
        /*Orientation Portrait */
        /*Root view Controller */
        iw2kBanner.frame=CGRectMake(20, 35, 288, 63);
        _searchField.frame= CGRectMake(20,103,280,44);
        liveResponsibilityButton.frame= CGRectMake(32,221,100,95);
        getScienceButton.frame= CGRectMake(113,153,100,95);
        beHealthyButton.frame= CGRectMake(113,299,100,95);
        goServeButton.frame= CGRectMake(193,221,100,95);
        
        /* Container */
        container.frame=CGRectMake(0, 0, 320, 480);
        extensionLogo.frame=CGRectMake(0, 437, 110, 43);
        fyfiLogo.frame=CGRectMake(207, 437, 113, 41);
        
        /*Extension Logo Webview */
        extentionWebView.frame=CGRectMake(0, 20, 320, 413);
        extensionWebViewToolbar.frame=CGRectMake(0, 433, 317, 44);
        
        /*FYFL Logo Webview */
        fyfiWebView.frame=CGRectMake(0, 20, 320, 413);
        fyfiWebViewToolbar.frame=CGRectMake(0, 433, 317, 44);
        
    }
    
}
-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    [self changedView:toInterfaceOrientation];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
- (IBAction)textFieldDoneEditing:(id)sender {
    [sender resignFirstResponder];
}
 */
-(IBAction)backgroundTap:(id)sender {
    [self.searchField resignFirstResponder];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:@"searchseg"]){
        searchViewController  *controller = (searchViewController *)segue.destinationViewController;
        controller.searchField = _searchField.text;
        
    }
}
@end
