//
//  FYFLLiveResponsiblyViewController.m
//  IW2K
//
//  Created by Connie McLaurin on 7/23/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import "FYFLLiveResponsiblyViewController.h"
#import "FYFLWebContentViewController.h"

@interface FYFLLiveResponsiblyViewController ()

@end

@implementation FYFLLiveResponsiblyViewController
@synthesize navigationBar;

@synthesize liveRespPic;
@synthesize goRespText;

@synthesize leadership;
@synthesize childrenMoney;
@synthesize talkMoney;
@synthesize teamBuild;
@synthesize youthInvolvement;

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIApplication *app= [UIApplication sharedApplication];
    UIInterfaceOrientation currentOrientation= app.statusBarOrientation;
    [self changedView:currentOrientation];
    // Do any additional setup after loading the view.
}

-(void)changedView:(UIInterfaceOrientation) orientation {
    UIInterfaceOrientation theOrientation = self.interfaceOrientation;
    if ( theOrientation==UIInterfaceOrientationLandscapeLeft || theOrientation == UIInterfaceOrientationLandscapeRight) {
        
        /*Orientation Landscape */
        /*Root view Controller */
        
        navigationBar.frame=CGRectMake(2, 10, 479, 44);
        
        liveRespPic.frame= CGRectMake(75,59,340,110);
        goRespText.frame= CGRectMake(29,159,432,37);
        
        
        leadership.frame= CGRectMake(37,193,110,30);
        childrenMoney.frame= CGRectMake(91,225,110,30);
        talkMoney.frame= CGRectMake(186,252,110,30);
        teamBuild.frame= CGRectMake(340,193,110,30);
        youthInvolvement.frame= CGRectMake(287,225,110,30);
        
        
    }
    else {
        navigationBar.frame=CGRectMake(0, 31, 320, 44);
        
        liveRespPic.frame= CGRectMake(31,84,269,115);
        goRespText.frame= CGRectMake(31,207,272,37);
        
        
        leadership.frame= CGRectMake(30,247,94,35);
        childrenMoney.frame= CGRectMake(78,281,94,35);
        talkMoney.frame= CGRectMake(113,315,105,35);
        teamBuild.frame= CGRectMake(158,350,90,35);
        youthInvolvement.frame= CGRectMake(197,386,99,35);
        
    }
    
}
-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    [self changedView:toInterfaceOrientation];
}





#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.destinationViewController isKindOfClass:[FYFLWebContentViewController class]])
    {
        FYFLWebContentViewController* controller = (FYFLWebContentViewController *) segue.destinationViewController;
        controller.viewTitle = segue.identifier;
        
        if ([segue.identifier isEqualToString:@"Teen Leadership"])
        {
            controller.urlToLoad = @"http://www.extension.org/pages/63736/teen-leadership-community-of-practice#.U9Aj3bGr91w";
        }
        else if ([segue.identifier isEqualToString:@"Children Money"])
        {
            controller.urlToLoad = @"http://www.extension.org/pages/8623/financial-security:-children-and-money#.U9AkM7Gr91w";
        }
        else if ([segue.identifier isEqualToString:@"Talking About Money"])
        {
            controller.urlToLoad = @"http://www.extension.org/pages/8635/financial-security:-talking-about-money#.U9AkaLGr91w";
        }
        else if ([segue.identifier isEqualToString:@"Team Building"])
        {
            controller.urlToLoad = @"https://ask.extension.org/questions/162249#.U9EYuPlkTh4";
        }
        else if ([segue.identifier isEqualToString:@"Youth Involvement"])
        {
            controller.urlToLoad = @"http://www.extension.org/pages/61734/youth-involvement-in-cooperatives#.U9EZWvlkTh4";
        }
    }

}


@end
