//
//  FYFLWebContentViewController.h
//  IW2K
//
//  Created by Ivelin Denev on 7/22/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FYFLWebContentViewController : UIViewController

@property NSString* urlToLoad;
@property NSString* viewTitle;



@end
