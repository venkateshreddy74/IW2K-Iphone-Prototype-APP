//
//  FYFLGetScienceViewController.m
//  IW2K
//
//  Created by Ivelin Denev on 7/22/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import "FYFLGetScienceViewController.h"
#import "FYFLWebContentViewController.h"

@interface FYFLGetScienceViewController ()

@end

@implementation FYFLGetScienceViewController
@synthesize navigationBar;
@synthesize getSciencePic;
@synthesize getScienceText;
@synthesize water;
@synthesize aerospace;
@synthesize geospatial;
@synthesize agriculture;
@synthesize math;
@synthesize nature;
@synthesize fourHScience;
@synthesize energy;


-(void)changedView:(UIInterfaceOrientation) orientation {
    UIInterfaceOrientation theOrientation = self.interfaceOrientation;
    if ( theOrientation==UIInterfaceOrientationLandscapeLeft || theOrientation == UIInterfaceOrientationLandscapeRight) {
        
        /*Orientation Landscape */
        /*Root view Controller */
         navigationBar.frame=CGRectMake(2, 10, 479, 44);
        
        getSciencePic.frame= CGRectMake(75,59,340,102);
        getScienceText.frame= CGRectMake(26,156,432,37);
        
        
        water.frame= CGRectMake(131,193,90,30);
        aerospace.frame= CGRectMake(246,193,90,30);
        geospatial.frame= CGRectMake(131,237,90,30);
        agriculture.frame= CGRectMake(24,193,90,30);
        math.frame= CGRectMake(368,193,90,30);
        nature.frame= CGRectMake(246,237,90,30);
        fourHScience.frame= CGRectMake(24,237,90,30);
        energy.frame= CGRectMake(368,237,90,30);
        
       
        
    }
    else {
        navigationBar.frame=CGRectMake(0, 12, 320, 44);
        
        getSciencePic.frame= CGRectMake(20,68,280,115);
        getScienceText.frame= CGRectMake(24,188,272,37);
        
        
        water.frame= CGRectMake(20,238,90,35);
        aerospace.frame= CGRectMake(200,233,90,35);
        geospatial.frame= CGRectMake(110,266,90,35);
        agriculture.frame= CGRectMake(24,302,90,35);
        math.frame= CGRectMake(200,302,90,35);
        nature.frame= CGRectMake(110,334,90,35);
        fourHScience.frame= CGRectMake(24,369,90,35);
        energy.frame= CGRectMake(200,369,90,35);
        
    }
    
}
-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    [self changedView:toInterfaceOrientation];
}




- (void)viewDidLoad
{
    [super viewDidLoad];
    UIApplication *app= [UIApplication sharedApplication];
    UIInterfaceOrientation currentOrientation= app.statusBarOrientation;
    [self changedView:currentOrientation];
    // Do any additional setup after loading the view.
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.destinationViewController isKindOfClass:[FYFLWebContentViewController class]]) {
        FYFLWebContentViewController* controller = (FYFLWebContentViewController *) segue.destinationViewController;
        controller.viewTitle = segue.identifier;
    
        if ([segue.identifier isEqualToString:@"Water"]) {
            controller.urlToLoad = @"http://www.extension.org/pages/55780/water-for-youth";
        }
        else if ([segue.identifier isEqualToString:@"Agriculture"]) {
            controller.urlToLoad = @"http://www.extension.org/pages/26656/get-in-the-ag-zone";
        }
        else if ([segue.identifier isEqualToString:@"Energy"]) {
            controller.urlToLoad = @"http://www.extension.org/pages/13614/energy";
        }
        else if ([segue.identifier isEqualToString:@"Geospetial"]) {
            controller.urlToLoad = @"http://www.extension.org/pages/15487/geospatial-technology";
        }
        else if ([segue.identifier isEqualToString:@"Nature"]) {
            controller.urlToLoad = @"http://www.extension.org/pages/22797/natural-environment";
        }
        else if ([segue.identifier isEqualToString:@"Aerospace"])
        {
            controller.urlToLoad = @"http://www.extension.org/pages/63261/for-youth-for-life:-aerospace#.U8_JlhZN0YV";
        }
        else if ([segue.identifier isEqualToString:@"4HScience"])
        {
            controller.urlToLoad = @"http://www.4-h.org/youth-development-programs/4-h-science-programs";
        }
        else if ([segue.identifier isEqualToString:@"Math"])
        {
            controller.urlToLoad = @"http://www.extension.org/pages/25598/young-childrens-developing-math-skills#.U8_KKRZN0YU";
        }
    
    
    }
    
    
    
    
}


@end
