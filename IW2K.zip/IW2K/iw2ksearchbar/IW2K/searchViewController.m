//
//  searchViewController.m
//  IW2K
//
//  Created by Kartheek Paidipalli on 7/26/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import "searchViewController.h"

@interface searchViewController ()

@end

@implementation searchViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    
    
    
    NSString *query = [_searchField  stringByReplacingOccurrencesOfString:@" " withString:@"+" ];
    NSString  *extension = @"extension.org";
    
    
    
    NSString* fullextension  = [NSString stringWithFormat:@"%@  %@",extension,query];
    NSString *final  = [fullextension   stringByReplacingOccurrencesOfString:@" " withString:@"+" ];
    
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://www.google.co.uk/search?q=%@", final]];
    
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    
    [_searchwebView  loadRequest:request];
    
    
    

    
    
    
    
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
