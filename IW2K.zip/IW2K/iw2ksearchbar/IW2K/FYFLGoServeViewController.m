//
//  FYFLGoServeViewController.m
//  IW2K
//
//  Created by Connie McLaurin on 7/23/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import "FYFLGoServeViewController.h"
#import "FYFLWebContentViewController.h"

@interface FYFLGoServeViewController ()

@end

@implementation FYFLGoServeViewController
@synthesize goServePic;
@synthesize goServeText;
@synthesize navigationBar;
@synthesize foundationForVolunteers;
@synthesize developingVolunteers;
@synthesize volunteerManagers;
@synthesize helpChildrenServe;
@synthesize volunteerOrientation;


-(void)changedView:(UIInterfaceOrientation) orientation {
    UIInterfaceOrientation theOrientation = self.interfaceOrientation;
    if ( theOrientation==UIInterfaceOrientationLandscapeLeft || theOrientation == UIInterfaceOrientationLandscapeRight) {
        
        /*Orientation Landscape */
        /*Root view Controller */
        navigationBar.frame=CGRectMake(2, 10, 479, 44);
        
        goServePic.frame= CGRectMake(75,59,340,102);
        goServeText.frame= CGRectMake(29,159,432,37);
        
        
        foundationForVolunteers.frame= CGRectMake(31,198,119,37);
        developingVolunteers.frame= CGRectMake(186,198,119,37);
        volunteerManagers.frame= CGRectMake(343,198,119,37);
        helpChildrenServe.frame= CGRectMake(92,235,119,37);
        volunteerOrientation.frame= CGRectMake(274,234,119,37);
        
    }
    else {
        navigationBar.frame=CGRectMake(0, 22, 320, 44);
        
        goServePic.frame= CGRectMake(20,66,280,128);
        goServeText.frame= CGRectMake(30,212,272,37);
        
        
        foundationForVolunteers.frame= CGRectMake(26,266,119,35);
        developingVolunteers.frame= CGRectMake(162,264,119,35);
        volunteerManagers.frame= CGRectMake(98,315,119,35);
        helpChildrenServe.frame= CGRectMake(27,363,119,35);
        volunteerOrientation.frame= CGRectMake(161,364,119,35);
        
    }
    
}
-(void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    [self changedView:toInterfaceOrientation];
}





- (void)viewDidLoad
{
    [super viewDidLoad];
    UIApplication *app= [UIApplication sharedApplication];
    UIInterfaceOrientation currentOrientation= app.statusBarOrientation;
    [self changedView:currentOrientation];
    // Do any additional setup after loading the view.
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.destinationViewController isKindOfClass:[FYFLWebContentViewController class]])
    {
        FYFLWebContentViewController* controller = (FYFLWebContentViewController *) segue.destinationViewController;
        controller.viewTitle = segue.identifier;
    
        
        if ([segue.identifier isEqualToString:@"Foundation for Volunteers"])
        {
            controller.urlToLoad = @"https://www.youtube.com/watch?v=zV49By6b_rw&feature=youtu.be";
        }
        else if ([segue.identifier isEqualToString:@"Volunteer Orientation"])
        {
            controller.urlToLoad = @"http://www.extension.org/pages/68880/what-is-the-purpose-of-volunteer-orientation#.U9KwmFZJ86F";
        }
        else if ([segue.identifier isEqualToString:@"Developing Volunteers"])
        {
            controller.urlToLoad = @"https://www.youtube.com/watch?v=tznj7Kg5uws&feature=youtu.be";
        }
        else if ([segue.identifier isEqualToString:@"Volunteer Managers"])
        {
            controller.urlToLoad = @"http://www.extension.org/pages/70973/what-is-a-volunteer-manager#.U9KwsFZJ86F";
        }
        else if ([segue.identifier isEqualToString:@"Help Children Serve"])
        {
            controller.urlToLoad = @"http://www.extension.org/pages/65010/helping-children-to-serve-themselves#U9EalflkTh4";
        }
    }
}


@end
