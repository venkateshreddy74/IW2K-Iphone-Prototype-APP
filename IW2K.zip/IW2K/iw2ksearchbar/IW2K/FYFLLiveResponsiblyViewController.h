//
//  FYFLLiveResponsiblyViewController.h
//  IW2K
//
//  Created by Connie McLaurin on 7/23/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FYFLLiveResponsiblyViewController : UIViewController

@property (weak, nonatomic) IBOutlet UINavigationBar *navigationBar;

@property (weak, nonatomic) IBOutlet UIImageView *liveRespPic;
@property (weak, nonatomic) IBOutlet UILabel *goRespText;

@property (weak, nonatomic) IBOutlet UIButton *leadership;
@property (weak, nonatomic) IBOutlet UIButton *childrenMoney;

@property (weak, nonatomic) IBOutlet UIButton *talkMoney;
@property (weak, nonatomic) IBOutlet UIButton *teamBuild;
@property (weak, nonatomic) IBOutlet UIButton *youthInvolvement;


@end
