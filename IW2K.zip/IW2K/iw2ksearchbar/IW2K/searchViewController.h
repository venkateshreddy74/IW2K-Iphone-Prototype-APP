//
//  searchViewController.h
//  IW2K
//
//  Created by Kartheek Paidipalli on 7/26/14.
//  Copyright (c) 2014 Auburn University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface searchViewController : UIViewController

@property(strong)NSString *searchField;
@property (weak, nonatomic) IBOutlet UIWebView *searchwebView;

@end
